<?php
/**
 * Displays footer bottom right content
 *
 * @package Cenote
 */

get_template_part( 'template-parts/menu/menu', 'social' );
