<?php
/**
 * Author:          Andrei Baicus <andrei@themeisle.com>
 * Created on:      27/08/2018
 *
 * @package Neve
 */

do_action( 'neve_blog_post_template_part_content', 'single' );
