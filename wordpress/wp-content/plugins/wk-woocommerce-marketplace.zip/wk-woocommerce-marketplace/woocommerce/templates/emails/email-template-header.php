<?php
/**
* Email Header
*
* @author  Webkul
* @version 4.7.1
*/


if ( ! defined( 'ABSPATH' ) ) {
exit; // Exit if accessed directly
}

?>
<!DOCTYPE html>
  <html>
        <head></head>
        <body>
            <table cellspacing="0" class="body-wrap">
                <tr style="margin:0px;">
                   <td class="alert alert-warning">
                          <h1><?php echo $heading; ?></td>
            </tr>
          <tr>
              <td class="container">
                <div class="content">
                  <table class="main" cellpadding="0" cellspacing="0" >
