<?php
/**
 * Seller New Order email
 *
 * @author Webkul
 * @package WooCommerce/Templates/Emails
 * @version 4.8.2
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

$order = new WC_Order( $data[0]->get_order_id() );

foreach ( $data as $key => $value ) {
	$product_id  = $value->get_product_id();
	$variable_id = $value->get_variation_id();
	$item_data   = array();
	$meta_dat    = $value->get_meta_data();
	$post        = get_post( $product_id );
	$qty         = $value->get_data()['quantity'];

	$product_total_price = $value->get_data()['total'];
	if ( ! empty( $meta_dat ) ) {
		foreach ( $meta_dat as $key1 => $value1 ) {
			$item_data[] = $meta_dat[ $key1 ]->get_data();
		}
	}

	$order_detail_by_order_id[ $product_id ][] = array(
		'product_name'        => $value['name'],
		'qty'                 => $qty,
		'variable_id'         => $variable_id,
		'product_total_price' => $product_total_price,
		'meta_data'           => $item_data,
	);
}

$total_payment = 0;

$shipping_method = $order->get_shipping_method();

$payment_method = $order->get_payment_method_title();

$result = '
<tr>
	<td valign="top">
		<div id="body_content_inner">
			<p>' . __( 'You have received an order from', 'marketplace' ) . '&nbsp;' . $order->get_formatted_billing_full_name() . '</p>
			<h3>Order #' . $order->get_ID() . ' (' . $order->get_date_created()->format( 'F j, Y' ) . ')</h3>
			<hr>
			<table class="order-details" id="body_content_inner" style="width:100%">
				<tr>
					<td class="th">' . __( 'Product', 'marketplace' ) . '</td>
					<td class="th">' . __( 'Quantity', 'marketplace' ) . '</td>
					<td class="th">' . __( 'Price', 'marketplace' ) . '</td>
				</tr>
				<tr>';

foreach ( $order_detail_by_order_id as $product_id => $details ) {
	$product = new WC_Product( $product_id );
	$detailc = 0;
	if ( count( $details ) > 0 ) {
		$detailc = count( $details );
	}
	for ( $i = 0; $i < $detailc; $i++ ) {
		$total_payment = floatval( $total_payment ) + floatval( $details[ $i ]['product_total_price'] ) + floatval( $order->get_total_shipping() );
		if ( $details[ $i ]['variable_id'] == 0 ) {
			$result .=
			'<tr class="order_item alt-table-row">
				<td class="product-name">
					<span>' . $details[ $i ]['product_name'] . '</span><br />
					<span>' . __( 'SKU: ', 'marketplace' ) . $product->get_sku() . '</span>
				</td>
				<td>' . $details[ $i ]['qty'] . '</td>
				<td class="product-total">
					' . wc_price( $details[ $i ]['product_total_price'], array( 'currency' => $order->get_currency() ) ) . '
				</td>
			</tr>';
		} else {
			$attribute = $product->get_attributes();

			$attribute_name = '';
			foreach ( $attribute as $key => $value ) {
				$attribute_name = $value['name'];
			}
			$result .=
			'<tr class="order_item alt-table-row">
				<td class="product-name">
					<span>' . $details[ $i ]['product_name'] . '</span>
					<br />
					<span>' . __( 'SKU: ', 'marketplace' ) . $product->get_sku() . '</span>
					<br />';
			if ( ! empty( $details[ $i ]['meta_data'] ) ) {
				foreach ( $details[ $i ]['meta_data'] as $m_data ) {
					$result .= '<b>' . wc_attribute_label( $m_data['key'] ) . '</b> : ' . strtoupper( $m_data['value'] ) . '<br>';
				}
			}

			$result .= '</td>
				<td>' . $details[ $i ]['qty'] . '</td>
				<td class="product-total">
					' . wc_price( $details[ $i ]['product_total_price'], array( 'currency' => $order->get_currency() ) ) . '
				</td>
			</tr>';
		}
	}
}

if ( ! empty( $shipping_method ) ) :
	$result .=
	'<tr>
		<th scope="row" colspan="2">' . __( 'Shipping', 'marketplace' ) . ' : </th>
		<td>' . wc_price( ( $order->get_total_shipping() ? $order->get_total_shipping() : 0 ), array( 'currency' => $order->get_currency() ) ) . '</td>
	</tr>';
endif;

if ( ! empty( $payment_method ) ) :
	$result .=
	'<tr>
		<th scope="row" colspan="2">' . __( 'Payment Method', 'marketplace' ) . ' : </th>
		<td>' . $payment_method . '</td>
	</tr>';
endif;

$result .=
	'<tr>
		<th scope="row" colspan="2">' . __( 'Total', 'marketplace' ) . ' : </th>
		<td>' . wc_price( $total_payment, array( 'currency' => $order->get_currency() ) ) . '</td>
	</tr>';

$result .=
'</tr>
</table>
<hr>';

if ( $order->get_customer_note() ) {
	$fields['customer_note'] = array(
		'label' => __( 'Note', 'marketplace' ),
		'value' => wptexturize( $order->get_customer_note() ),
	);
}

if ( $order->get_billing_email() ) {
	$fields['billing_email'] = array(
		'label' => __( 'Email address', 'marketplace' ),
		'value' => wptexturize( $order->get_billing_email() ),
	);
}

if ( $order->get_billing_phone() ) {
	$fields['billing_phone'] = array(
		'label' => __( 'Phone', 'marketplace' ),
		'value' => wptexturize( $order->get_billing_phone() ),
	);
}

if ( ! empty( $fields ) ) :
	$result .= '<h2>' . __( 'Customer details', 'marketplace' ) . '</h2><p>';
	foreach ( $fields as $field ) :
		$result .= '<strong>' . wp_kses_post( $field['label'] ) . ':</strong> ' . wp_kses_post( $field['value'] ) . '<br />';
	endforeach;
	$result .= '</p>';
endif;

$text_align = is_rtl() ? 'right' : 'left';

$result .=
'<table id="addresses" style="width:100%">
<tr>
	<td class="td" valign="top" width="49%">
		<h3>' . __( 'Billing address', 'marketplace' ) . '</h3>

		<p class="text">' . $order->get_formatted_billing_address() . '</p>
	</td>';

if ( ! wc_ship_to_billing_address_only() && $order->needs_shipping_address() ) :

	$shipping = '';

	if ( $order->get_formatted_shipping_address() ) :

		$shipping = $order->get_formatted_shipping_address();
	endif;

	if ( ! empty( $shiping ) ) {

		$result .=
		'<td class="td" valign="top" width="49%">
		<h3>' . __( 'Shipping address', 'marketplace' ) . '</h3>

		<p class="text">' . $shipping . '</p>
		</td>';
	}
endif;

$result .=
'</tr>
</table>';

$result .=
		'</div>
	</td>
</tr>';

return $result;
