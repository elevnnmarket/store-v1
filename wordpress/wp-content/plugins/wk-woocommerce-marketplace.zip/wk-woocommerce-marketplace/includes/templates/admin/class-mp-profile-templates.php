<?php

if( ! defined ( 'ABSPATH' ) )

    exit;

function extra_user_profile_fields( $user ){
    require_once( 'account/user-profile.php' );
}
